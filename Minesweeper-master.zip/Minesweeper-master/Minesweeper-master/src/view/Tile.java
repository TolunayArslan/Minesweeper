package view;

import java.awt.*;
import java.awt.image.BufferedImage;

public class Tile {

    private BufferedImage image;

    private int x;
    private int y;


    // Hier wird errechnet wie viele Tiles gesetzt werden müssen
    private static int widthTile = GUI.getFrameWidth()/G_Field.getWidth();
    private static int heightTile = GUI.getFrameHeight()/G_Field.getHeight();




    // zwar nicht zwingend notwendig/ die Methode garantiert das ein Teil 1 zu 1 Groß ist
    public void tileLengthCheck(){
    if( heightTile != widthTile ){
        System.err.println("error");
    }else {
        // the sides of the tiles have the same lenght
    }
    }

    public Tile(int x, int y){
        this.x = x;
        this.y = y;


    }

    public void tileSpreading(Graphics spread){
        spread.drawImage( image, x*widthTile, y*heightTile, null);
    }//verteilt die Tiles auf dem Feld



    public static int getHeight(){
        return heightTile;
    }

    public static int getWidth() {
    return widthTile;
    }

    // Die Methode soll das BufferedImage setzen. Also setz das Tile wenn es ungeklickt ist.
    public void setImage(BufferedImage unpressed) {
        this.image = image;
    }
}
