package view;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;


public class G_Field {

    private BufferedImage mine = ImageLoader.scale(ImageLoader.loadImage("Images/Icon.png"), Tile.getWidth(), Tile.getHeight());
    private BufferedImage flag= ImageLoader.scale(ImageLoader.loadImage("Images/Icon6_2.png"), Tile.getWidth(), Tile.getHeight());
    private BufferedImage unpressed = ImageLoader.scale(ImageLoader.loadImage("Images/tile_paint.png"), Tile.getWidth(), Tile.getHeight());
    private BufferedImage pressed = ImageLoader.scale(ImageLoader.loadImage("Images/Tile_1.png"), Tile.getWidth(), Tile.getHeight());


    private static int width = 40;
    private static int height = 40;

    private Tile[] [] tilesArray;

    public G_Field() throws IOException {
        tilesArray = new Tile[width][height];
        for (int x = 0; x < width; x++) {

            for (int y = 0; y < height; y++) {
                tilesArray[x] [y] = new Tile(x,y);
                tilesArray[x] [y].setImage(unpressed);
            }
        }
    }
    public static int getHeight() {
        return height;
    }

    public static int getWidth() {
        return width;
    }

    // Verteilt die Tiles auf dem Feld mit einer for-Schleife in x und y Richtung
    public void tileSpreading(Graphics spread){
        for (int x = 0; x < width; x++) {

            for (int y = 0; y < height; y++) {
                tilesArray[x] [y].tileSpreading(spread);

            }
        }
    }






}
