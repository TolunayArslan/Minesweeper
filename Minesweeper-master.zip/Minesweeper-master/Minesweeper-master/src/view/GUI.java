package view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;

public class GUI extends JFrame {

    public static int width = 400;
    public static int height = 400;

    private static G_Field playground;
    private  frameField framefield;

        public JFrame frame;
        public JMenuBar menuBar;
        public JMenu menuPointOne, menuPointTwo;
        public JMenuItem menuItemOne;

        public GUI() throws IOException {
            playground = new G_Field();


            framefield = new frameField();
            add(framefield);
            
        //Die Menüleiste starten hier und endet.......    
            menuBar = new JMenuBar();

            menuPointOne = new JMenu("File");
            menuBar.add(menuPointOne);

            menuPointTwo = new JMenu("Restart");
            menuBar.add(menuPointTwo);

            menuItemOne = new JMenuItem("30*30", new ImageIcon("//C:/Users/kai_r/eclipse-workspace/Minsweeper/src/Images/Icon.png"));
            menuPointOne.add(menuItemOne);
            menuPointOne.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {

                }
                
              
                
            });
            
            menuItemOne = new JMenuItem("60*60", new ImageIcon("//C:/Users/kai_r/eclipse-workspace/Minsweeper/src/Images/Icon.png")); // Auswahl für das Feld 60x60, img wirft vllt eine Exception da ich es Momentan mit einem Dateipfad auf meinem Pc verbunden hab
            menuPointOne.add(menuItemOne);
            
            //und endet hier. Der actinListener hat noch keine Funktion, weil der wird ja später über die Viewcontrol verbunden.
            // Hier ist das JFrame definiert
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            setVisible(true);
            setSize(width, height);
            setLocationRelativeTo(null);
            setVisible(true);
            setResizable(false);

            setJMenuBar(menuBar);

            ImageIcon image = new ImageIcon("//C:/Users/kai_r/eclipse-workspace/Minsweeper/src/Images/Icon.png");
            setIconImage(image.getImage());

        }


    //Getter und Setter
    public static int getFrameWidth(){
            return width;
        }

        public static int getFrameHeight(){
            return height;
        }


// frameField fügt die Tiles hinzu, funktioniert momentan aber noch nicht.
    // das Rote Feld funktioniert aber die Tiles weden momentan noch nicht aufgerufen
    // Wenn des mit den Images nicht klappt dann müssen wir halt graue Flächen nehmen
    public static class frameField extends JPanel{
             public void paintComponent(Graphics g) {
                 g.setColor(Color.RED);
                 g.fillRect(0,0,50,50);
                 playground.tileSpreading(g); // die Verbindung zu der Methode tileSpreading(g) aus G_Field funktioniert eventuell nicht, oder muss ich des über frameField() laufen lassen?
             }


    }



}



