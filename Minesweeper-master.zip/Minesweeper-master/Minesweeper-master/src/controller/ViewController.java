package controller;

import view.GUI;
import model.Minesweeper;

import java.awt.*;
import java.io.IOException;


public class ViewController {
    public static void main(String[] args) throws IOException {
        new GUI();

    }
}


